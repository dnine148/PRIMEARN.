import { Metadata } from "next"
import { BalanceCard } from "@/components/dashboard/balance-card"
import { StatsCard } from "@/components/dashboard/stats-card"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"

export const metadata: Metadata = {
  title: "Dashboard - Primemart",
  description: "Your Primemart dashboard",
}

export default function DashboardPage() {
  return (
    <div className="space-y-4 p-4">
      <BalanceCard balance={10900} plan="Basic Plan" />
      <div className="grid gap-4 md:grid-cols-2">
        <StatsCard title="Tasks" value="₦10,500" />
        <StatsCard title="Referral" value="₦400" />
      </div>
      <StatsCard title="Total Referrals" value="7" />
      <Card className="p-4">
        <div className="flex space-x-2">
          <Input
            readOnly
            value="https://primemartng.online"
            className="font-mono"
          />
          <Button>Copy</Button>
        </div>
      </Card>
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold">Weekly Top Earners</h2>
          <Button variant="link">View All</Button>
        </div>
        {/* Add top earners list here */}
      </div>
    </div>
  )
}

