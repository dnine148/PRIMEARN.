import { Metadata } from "next"
import Link from "next/link"
import { Logo } from "@/components/ui/logo"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"

export const metadata: Metadata = {
  title: "Login - Primemart",
  description: "Login to your Primemart account",
}

export default function LoginPage() {
  return (
    <div className="container relative min-h-screen flex-col items-center justify-center grid lg:max-w-none lg:grid-cols-1 lg:px-0">
      <div className="p-4 space-y-6 w-full max-w-sm mx-auto">
        <div className="flex justify-center">
          <Logo />
        </div>
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <h1 className="text-2xl font-bold">Sign in to account</h1>
                <p className="text-muted-foreground">
                  Enter your username & password to login
                </p>
              </div>
              <form action="#" className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="username">Username</label>
                  <Input id="username" placeholder="Username" required />
                </div>
                <div className="space-y-2">
                  <label htmlFor="password">Password</label>
                  <Input id="password" type="password" required />
                </div>
                <Button type="submit" className="w-full">
                  Sign in
                </Button>
              </form>
              <div className="text-sm">
                <Link href="/forgot-password" className="text-primary">
                  Forgot password
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
        <div className="text-center text-sm">
          Don&apos;t have account?{" "}
          <Link href="/register" className="text-primary font-medium">
            Create Account
          </Link>
        </div>
      </div>
    </div>
  )
}

