import { Metadata } from "next"
import Link from "next/link"
import { Logo } from "@/components/ui/logo"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

export const metadata: Metadata = {
  title: "Register - Primemart",
  description: "Create your Primemart account",
}

export default function RegisterPage() {
  return (
    <div className="container relative min-h-screen flex-col items-center justify-center grid lg:max-w-none lg:grid-cols-1 lg:px-0">
      <div className="p-4 space-y-6 w-full max-w-sm mx-auto">
        <div className="flex justify-center">
          <Logo />
        </div>
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <h1 className="text-2xl font-bold">Sign up for an account</h1>
                <p className="text-muted-foreground">
                  Enter your correct details to get started
                </p>
              </div>
              <form action="#" className="space-y-4">
                <div className="space-y-2">
                  <label htmlFor="username">Username</label>
                  <Input id="username" placeholder="Username" required />
                </div>
                <div className="space-y-2">
                  <label htmlFor="email">Email Address</label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Email address"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="phone">Phone Number</label>
                  <Input id="phone" type="tel" placeholder="Phone" required />
                </div>
                <div className="space-y-2">
                  <label htmlFor="country">Select Country</label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select Country" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="nigeria">Nigeria</SelectItem>
                      <SelectItem value="ghana">Ghana</SelectItem>
                      <SelectItem value="kenya">Kenya</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label htmlFor="referral">Referral Username (optional)</label>
                  <Input id="referral" placeholder="Referral Username" />
                </div>
                <div className="space-y-2">
                  <label htmlFor="password">Password</label>
                  <Input id="password" type="password" required />
                </div>
                <Button type="submit" className="w-full">
                  Sign up
                </Button>
              </form>
            </div>
          </CardContent>
        </Card>
        <div className="text-center text-sm">
          Already have account?{" "}
          <Link href="/login" className="text-primary font-medium">
            Login Account
          </Link>
        </div>
      </div>
    </div>
  )
}

