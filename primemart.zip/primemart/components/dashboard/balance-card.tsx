import { Card } from "@/components/ui/card"
import { formatCurrency } from "@/lib/utils"

interface BalanceCardProps {
  balance: number
  plan: string
}

export function BalanceCard({ balance, plan }: BalanceCardProps) {
  return (
    <Card className="bg-primary text-primary-foreground p-6 relative overflow-hidden">
      <div className="space-y-2">
        <h2 className="text-lg font-medium">Account Balance</h2>
        <p className="text-3xl font-bold">{formatCurrency(balance)}</p>
        <p className="text-lg">{plan}</p>
      </div>
      <div className="absolute right-0 top-0">
        <div className="w-32 h-32 transform rotate-45 translate-x-16 -translate-y-8 bg-white/10" />
      </div>
    </Card>
  )
}

