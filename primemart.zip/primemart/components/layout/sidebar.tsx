"use client"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Sheet, SheetContent } from "@/components/ui/sheet"
import {
  Home,
  ListTodo,
  Share2,
  Users,
  Activity,
  CreditCard,
  Settings,
  MonitorSmartphone,
} from "lucide-react"
import { Logo } from "../ui/logo"
import Link from "next/link"
import { usePathname } from "next/navigation"

interface SidebarProps {
  isOpen: boolean
  onClose: () => void
}

export function Sidebar({ isOpen, onClose }: SidebarProps) {
  const pathname = usePathname()

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="left" className="p-0">
        <div className="space-y-4 py-4">
          <div className="px-3 py-2">
            <Logo />
          </div>
          <div className="px-3 py-2">
            <h2 className="mb-2 px-4 text-lg font-semibold tracking-tight">
              Menu
            </h2>
            <div className="space-y-1">
              <Button
                variant="ghost"
                className="w-full justify-start"
                asChild
              >
                <Link
                  href="/dashboard"
                  className={cn(
                    pathname === "/dashboard" && "bg-muted"
                  )}
                >
                  <Home className="mr-2 h-4 w-4" />
                  Dashboard
                </Link>
              </Button>
            </div>
          </div>
          <div className="px-3 py-2">
            <h2 className="mb-2 px-4 text-lg font-semibold tracking-tight">
              TODO
            </h2>
            <div className="space-y-1">
              <Button
                variant="ghost"
                className="w-full justify-start"
                asChild
              >
                <Link
                  href="/tasks"
                  className={cn(
                    pathname === "/tasks" && "bg-muted"
                  )}
                >
                  <ListTodo className="mr-2 h-4 w-4" />
                  Daily Tasks
                </Link>
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start"
                asChild
              >
                <Link
                  href="/sponsored"
                  className={cn(
                    pathname === "/sponsored" && "bg-muted"
                  )}
                >
                  <MonitorSmartphone className="mr-2 h-4 w-4" />
                  Sponsored Posts
                </Link>
              </Button>
            </div>
          </div>
          <div className="px-3 py-2">
            <h2 className="mb-2 px-4 text-lg font-semibold tracking-tight">
              Stats
            </h2>
            <div className="space-y-1
">
              <Button
                variant="ghost"
                className="w-full justify-start"
                asChild
              >
                <Link
                  href="/top-earners"
                  className={cn(
                    pathname === "/top-earners" && "bg-muted"
                  )}
                >
                  <Activity className="mr-2 h-4 w-4" />
                  Top Earners
                </Link>
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start"
                asChild
              >
                <Link
                  href="/downlines"
                  className={cn(
                    pathname === "/downlines" && "bg-muted"
                  )}
                >
                  <Users className="mr-2 h-4 w-4" />
                  My Downlines
                </Link>
              </Button>
            </div>
          </div>
          <div className="px-3 py-2">
            <h2 className="mb-2 px-4 text-lg font-semibold tracking-tight">
              More
            </h2>
            <div className="space-y-1">
              <Button
                variant="ghost"
                className="w-full justify-start"
                asChild
              >
                <Link
                  href="/plans"
                  className={cn(
                    pathname === "/plans" && "bg-muted"
                  )}
                >
                  <Share2 className="mr-2 h-4 w-4" />
                  Activate Plan
                </Link>
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start"
                asChild
              >
                <Link
                  href="/withdraw"
                  className={cn(
                    pathname === "/withdraw" && "bg-muted"
                  )}
                >
                  <CreditCard className="mr-2 h-4 w-4" />
                  Withdraw Money
                </Link>
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start"
                asChild
              >
                <Link
                  href="/settings"
                  className={cn(
                    pathname === "/settings" && "bg-muted"
                  )}
                >
                  <Settings className="mr-2 h-4 w-4" />
                  Account Settings
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}

