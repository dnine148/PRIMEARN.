import { Menu } from 'lucide-react'
import { Logo } from "./logo"
import { Button } from "./button"
import { ModeToggle } from "./mode-toggle"

interface MobileHeaderProps {
  onMenuClick: () => void
}

export function MobileHeader({ onMenuClick }: MobileHeaderProps) {
  return (
    <header className="flex items-center justify-between p-4 border-b">
      <Button variant="ghost" size="icon" onClick={onMenuClick}>
        <Menu className="h-6 w-6" />
      </Button>
      <Logo />
      <ModeToggle />
    </header>
  )
}

