export function Logo() {
  return (
    <div className="flex items-center space-x-2">
      <div className="bg-primary p-1 rounded">
        <div className="w-6 h-6 bg-white" />
      </div>
      <span className="font-bold text-xl text-primary">PRIMEMART</span>
    </div>
  )
}

